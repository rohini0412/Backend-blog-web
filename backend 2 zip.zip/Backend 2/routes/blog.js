const express = require("express") ;

const router = express.Router() ;

 
 const {createComment} = require("../controllers/commentController") ;
 const {createPost , getAllPost} = require("../controllers/postController") ;
 const {likepost} = require("../controllers/likeController") ;
const {unlikepost} = require("../controllers/likeController") ;


router.post("/create/comment" ,createComment) ;
router.post("/create/post" ,createPost) ;
router.get("/get/post" ,getAllPost) ;
router.post("/create/like" ,likepost) ;
router.post("/like/delete" ,unlikepost) ;

module.exports = router ;