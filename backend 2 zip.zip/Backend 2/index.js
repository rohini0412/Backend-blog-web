const express = require("express") ;
const app = express() ;

require("dotenv").config() ;

const PORT = process.env.PORT || 4000  ;
 
//  middleware add

app.use(express.json()) ;

// importing the routes 

const blog = require("./routes/blog") ;
 
//mount 

app.use("/api/v1" , blog) ;

// database 

const dbconnect = require("./config/database") ;
dbconnect() ;

app.listen(PORT,()=>{
    console.log(`App has started at ${ PORT }`) ;
})

app.get("/",(req ,res)=>{
    res.send("blog app has started") ;
})